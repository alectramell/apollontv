#!/bin/bash

clear

USERNAME=$(whoami)
WHEREAMI=$(pwd)

clear

rm /home/$USERNAME/Desktop/.stream.txt

clear

wget -O /home/$USERNAME/Desktop/.stream.txt https://github.com/alectramell/apollontv/raw/master/stream.txt

clear

sleep 0.5

clear

STREAM=$(cat /home/$USERNAME/Desktop/.stream.txt)
stream="$STREAM"

clear

fullscreen() {

	clear
	notify-send --urgency="critical" --icon="/usr/share/apollontv/apollontv.svg" "Apollon TV" "..Loading Media.." &
	clear
	mplayer -fs $(youtube-dl -g $stream) &
	clear
	notify-send --urgency="critical" --icon="/usr/share/apollontv/apollontv.svg" "Apollon TV" "..Press [ESC] to Quit Stream.."
	clear
}

clear

window() {

	clear
	notify-send --urgency="critical" --icon="/usr/share/apollontv/apollontv.svg" "Apollon TV" "..Loading Media.." &
	clear
	mplayer -x 750 -y 450 $(youtube-dl -g $stream) &
	clear
	notify-send --urgency="critical" --icon="/usr/share/apollontv/apollontv.svg" "Apollon TV" "..Use [ESC] to Quit Stream.."
	clear

}

clear

$1
