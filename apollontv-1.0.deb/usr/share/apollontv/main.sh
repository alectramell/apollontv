#!/bin/bash

clear

USERNAME=$(whoami)
WHEREAMI=$(pwd)

clear

SLOG=$(find /home/$USERNAME/Desktop/.stream.txt)

clear

if [ "$SLOG" = "/home/$USERNAME/Desktop/.stream.txt" ]
then
	clear
	echo "VOID REMOVE STREAM LOG"
	sleep 1.5
	clear
else
	clear
	rm /home/$USERNAME/Desktop/.stream.txt
	clear
	wget -O /home/$USERNAME/Desktop/.stream.txt https://github.com/alectramell/apollontv/raw/master/stream.txt
	clear
	sleep 0.5
	clear
fi

clear

STREAM=$(cat /home/$USERNAME/Desktop/.stream.txt)
stream="$STREAM"

clear

fullscreen() {

	clear
	VURL=$(zenity --entry --title="Apollon TV" --entry-text="$stream" --text="Enter Video URL (or use default stream): ") && notify-send --urgency="critical" --icon="/usr/share/apollontv/apollontv.svg" "Apollon TV" "..Loading Media.." && notify-send --urgency="critical" --icon="/usr/share/apollontv/apollontv.svg" "Apollon TV" "..Use [ESC] to Quit Stream.."
	clear
	mplayer -ao pulse -fs $(youtube-dl -g $VURL) &
	clear
}

clear

window() {

	clear
	VURL=$(zenity --entry --title="Apollon TV" --entry-text="$stream" --text="Enter Video URL (or use default stream): ") && notify-send --urgency="critical" --icon="/usr/share/apollontv/apollontv.svg" "Apollon TV" "..Loading Media.." && notify-send --urgency="critical" --icon="/usr/share/apollontv/apollontv.svg" "Apollon TV" "..Use [ESC] to Quit Stream.."
	clear
	mplayer -ao pulse -x 750 -y 450 $(youtube-dl -g $VURL) &
	clear

}

clear

$1
