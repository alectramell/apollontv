#!/bin/bash

clear

USERNAME=$(whoami)
WHEREAMI=$(pwd)

clear

rm /home/$USERNAME/Desktop/.netstatus.txt

clear

touch /home/$USERNAME/Desktop/.netstatus.txt

clear

XLIST=$(cat /usr/share/apollontv/netlist.txt)

clear

iwgetid -r > /home/$USERNAME/Desktop/.netstatus.txt

clear

ITEM=$(grep -c -iE "$XLIST" /home/$USERNAME/Desktop/.netstatus.txt)

clear

if [ $ITEM -gt 0 ]
then
	echo "TRUE"
	clear
	bash /usr/share/apollontv/updatestream.sh
	clear
else
	echo "FALSE"
	notify-send --urgency="critical" --icon="/usr/share/apollontv/error.svg" "OFFLINE!" "..Check Internet Connection.."
	clear
fi
