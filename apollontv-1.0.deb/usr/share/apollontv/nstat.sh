#!/bin/bash

clear

USERNAME=$(whoami)
WHEREAMI=$(pwd)

clear

rm /home/$USERNAME/Desktop/.netstatus.txt

clear

touch /home/$USERNAME/Desktop/.netstatus.txt

clear

XLIST=$(cat /usr/share/apollontv/netlist.txt)

clear

iwgetid -r > /home/$USERNAME/Desktop/.netstatus.txt

clear

ITEM=$(grep -c -iE "$XLIST" /home/$USERNAME/Desktop/.netstatus.txt)

clear

if [ $ITEM -gt 0 ]
then
	clear
	notify-send --urgency="critical" --icon="/usr/share/apollontv/upstream.svg" "Update Complete!" "..You can now test the default stream.."
	echo "TRUE"
	clear
	bash /usr/share/apollontv/main.sh $1
	clear
else
	echo "FALSE"
	notify-send --urgency="critical" --icon="/usr/share/apollontv/error.svg" "OFFLINE!" "..Check Internet Connection.."
	clear
fi
