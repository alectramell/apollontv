#!/bin/bash

clear

USERNAME=$(whoami)
WHEREAMI=$(pwd)

clear

zenity --question --title="Apollon TV | Confirm Stream Update" --text="Would you like to Update Default Stream?" --width="300" && rm /home/$USERNAME/Desktop/.stream.txt && bash /usr/share/apollontv/nstat.sh

clear
